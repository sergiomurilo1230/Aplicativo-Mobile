package com.atelier.control.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.atelier.control.database.AppDatabase
import com.atelier.control.model.Cliente
import com.atelier.control.model.Servico
import com.atelier.control.model.ServicoComCliente
import com.atelier.control.repository.AtelieRepository
import kotlinx.coroutines.launch

/**
 * ViewModel para gerenciar dados de Serviços
 *
 * Responsabilidades:
 * - Gerenciar estado dos serviços
 * - Executar operações de inserção, atualização e deleção
 * - Emitir dados para a View através de LiveData
 */
class ServicoViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AtelieRepository

    // LiveData que observa todos os serviços com cliente
    val todosServicos: LiveData<List<ServicoComCliente>>

    // LiveData que observa todos os clientes (para seleção no formulário)
    val todosClientes: LiveData<List<Cliente>>

    init {
        val database = AppDatabase.getDatabase(application)
        val clienteDao = database.clienteDao()
        val servicoDao = database.servicoDao()
        repository = AtelieRepository(clienteDao, servicoDao)

        // Converte Flow em LiveData
        todosServicos = repository.obterTodosServicos().asLiveData()
        todosClientes = repository.obterTodosClientes().asLiveData()
    }

    /**
     * Insere um novo serviço
     */
    fun inserirServico(clienteId: Int, descricao: String, dataEntrega: String, valor: String) {
        viewModelScope.launch {
            val servico = Servico(
                clienteId = clienteId,
                descricao = descricao,
                dataEntrega = dataEntrega,
                valor = valor
            )
            repository.inserirServico(servico)
        }
    }

    /**
     * Deleta um serviço
     */
    fun deletarServico(servicoId: Int, descricao: String, dataEntrega: String, valor: String, clienteId: Int) {
        viewModelScope.launch {
            val servico = Servico(
                id = servicoId,
                clienteId = clienteId,
                descricao = descricao,
                dataEntrega = dataEntrega,
                valor = valor
            )
            repository.deletarServico(servico)
        }
    }

    /**
     * Atualiza um serviço
     */
    fun atualizarServico(servicoId: Int, clienteId: Int, descricao: String, dataEntrega: String, valor: String) {
        viewModelScope.launch {
            val servico = Servico(
                id = servicoId,
                clienteId = clienteId,
                descricao = descricao,
                dataEntrega = dataEntrega,
                valor = valor
            )
            repository.atualizarServico(servico)
        }
    }
}
