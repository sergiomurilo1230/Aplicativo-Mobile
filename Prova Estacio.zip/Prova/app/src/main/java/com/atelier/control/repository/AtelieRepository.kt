package com.atelier.control.repository

import com.atelier.control.database.ClienteDao
import com.atelier.control.database.ServicoDao
import com.atelier.control.model.Cliente
import com.atelier.control.model.Servico
import com.atelier.control.model.ServicoComCliente
import kotlinx.coroutines.flow.Flow

/**
 * Repository - Camada intermediária entre ViewModel e DAO
 * Centraliza a lógica de acesso aos dados
 *
 * Benefícios do Repository:
 * 1. Abstrai a lógica de dados do ViewModel
 * 2. Facilita testes unitários
 * 3. Permite trocar a fonte de dados facilmente
 */
class AtelieRepository(
    private val clienteDao: ClienteDao,
    private val servicoDao: ServicoDao
) {

    // ========== Operações com Clientes ==========

    /**
     * Insere um novo cliente
     */
    suspend fun inserirCliente(cliente: Cliente): Long {
        return clienteDao.inserir(cliente)
    }

    /**
     * Atualiza um cliente existente
     */
    suspend fun atualizarCliente(cliente: Cliente) {
        clienteDao.atualizar(cliente)
    }

    /**
     * Deleta um cliente
     */
    suspend fun deletarCliente(cliente: Cliente) {
        clienteDao.deletar(cliente)
    }

    /**
     * Obtém todos os clientes
     */
    fun obterTodosClientes(): Flow<List<Cliente>> {
        return clienteDao.obterTodos()
    }

    /**
     * Obtém um cliente pelo ID
     */
    suspend fun obterClientePorId(id: Int): Cliente? {
        return clienteDao.obterPorId(id)
    }

    /**
     * Obtém um cliente pelo nome
     */
    suspend fun obterClientePorNome(nome: String): Cliente? {
        return clienteDao.obterPorNome(nome)
    }

    // ========== Operações com Serviços ==========

    /**
     * Insere um novo serviço
     */
    suspend fun inserirServico(servico: Servico): Long {
        return servicoDao.inserir(servico)
    }

    /**
     * Atualiza um serviço existente
     */
    suspend fun atualizarServico(servico: Servico) {
        servicoDao.atualizar(servico)
    }

    /**
     * Deleta um serviço
     */
    suspend fun deletarServico(servico: Servico) {
        servicoDao.deletar(servico)
    }

    /**
     * Obtém todos os serviços com informações do cliente
     */
    fun obterTodosServicos(): Flow<List<ServicoComCliente>> {
        return servicoDao.obterTodosComCliente()
    }

    /**
     * Obtém um serviço pelo ID
     */
    suspend fun obterServicoPorId(id: Int): Servico? {
        return servicoDao.obterPorId(id)
    }

    /**
     * Obtém todos os serviços de um cliente
     */
    fun obterServicosDoCliente(clienteId: Int): Flow<List<Servico>> {
        return servicoDao.obterPorClienteId(clienteId)
    }

    /**
     * Conta quantos serviços um cliente tem
     */
    suspend fun contarServicosDoCliente(clienteId: Int): Int {
        return servicoDao.contarServicosDoCliente(clienteId)
    }
}
