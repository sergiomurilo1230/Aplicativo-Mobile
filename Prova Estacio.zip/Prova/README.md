# Ateliê Control 👗

Aplicativo Android nativo para gerenciar um ateliê de costura de forma simples e prática.

## 📱 O que é?

Um aplicativo mobile para microempreendedoras que trabalham com costura e precisam organizar seus clientes e serviços de forma simples e sem complicações.

## ✨ Funcionalidades

- ✅ **Cadastro de Clientes** - Registre nome e telefone dos clientes
- ✅ **Registro de Serviços** - Descreva o tipo de costura, data de entrega e valor
- ✅ **Listagem de Serviços** - Veja todos os serviços cadastrados
- ✅ **Deletar Serviços** - Remova serviços da lista
- ✅ **Formatação de Moeda** - Valores em padrão brasileiro (R$)
- ✅ **Seleção de Data** - DatePicker para facilitar entrada de datas
- ✅ **Material Design 3** - Interface moderna e intuitiva

---

## 🏗️ Arquitetura do Projeto

O projeto segue o padrão **MVVM** (Model-View-ViewModel) para manter o código organizado e fácil de manter.

```
com.atelier.control/
├── model/
│   ├── Cliente.kt                    # Entidade Cliente
│   ├── Servico.kt                    # Entidade Serviço
│   └── ServicoComCliente.kt         # DTO para exibição
├── database/
│   ├── ClienteDao.kt                # Operações com clientes
│   ├── ServicoDao.kt                # Operações com serviços
│   └── AppDatabase.kt               # Configuração Room
├── repository/
│   └── AtelieRepository.kt          # Centraliza acesso aos dados
├── viewmodel/
│   ├── ClienteViewModel.kt          # Lógica de clientes
│   └── ServicoViewModel.kt          # Lógica de serviços
├── ui/
│   ├── activity/
│   │   ├── MainActivity.kt          # Tela inicial
│   │   ├── CadastroClienteActivity.kt
│   │   ├── RegistroServicoActivity.kt
│   │   └── ListaServicosActivity.kt
│   └── adapter/
│       └── ServicoAdapter.kt        # Adapter para RecyclerView
└── res/
    ├── layout/                      # Arquivos XML das telas
    ├── drawable/                    # Ícones
    ├── values/                      # Cores, strings, temas
    └── ...
```

---

## 📊 Banco de Dados (Room)

### Como funciona Room?

Room é uma abstração do SQLite que facilita o trabalho com banco de dados no Android:

1. **Entidades** - Classes que representam as tabelas
2. **DAOs** - Definem as operações SQL (Insert, Update, Delete, Select)
3. **Database** - Gerencia o banco de dados e fornece acesso aos DAOs

### Tabelas

#### `clientes`
```sql
CREATE TABLE clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT NOT NULL
)
```

#### `servicos`
```sql
CREATE TABLE servicos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clienteId INTEGER NOT NULL,
    descricao TEXT NOT NULL,
    dataEntrega TEXT NOT NULL,
    valor TEXT NOT NULL,
    FOREIGN KEY (clienteId) REFERENCES clientes(id) ON DELETE CASCADE
)
```

---

## 🚀 Como Rodar o Projeto

### Pré-requisitos
- Android Studio (versão 4.2 ou superior)
- SDK Android 26 (ou superior)
- JDK 8 (ou superior)

### Passos

1. **Clone ou abra o projeto no Android Studio**
   ```bash
   git clone https://github.com/seu-usuario/atelier-control.git
   cd atelier-control
   ```

2. **Abra em Android Studio**
   - File → Open → Selecione a pasta do projeto

3. **Sincronize o Gradle**
   - Android Studio pedirá para sincronizar automaticamente
   - Se não, acione: Build → Clean Project → Rebuild Project

4. **Execute no emulador ou dispositivo**
   - Clique em "Run" (botão verde play)
   - Selecione o emulador ou dispositivo conectado

5. **Pronto!** 🎉
   - O app abrirá na tela inicial

---

## 💾 Detalhes do Banco de Dados

### Onde os dados são salvos?

Os dados são salvos no banco de dados SQLite do dispositivo em:
```
/data/data/com.atelier.control/databases/atelier_database
```

### Como o banco é criado?

1. Quando o app é instalado, o Room cria automaticamente o banco na primeira inicialização
2. As tabelas são criadas baseadas nas entidades (@Entity)
3. O banco existe enquanto o app está instalado

### Como acessar o banco em desenvolvimento?

**Via Android Studio (Device File Explorer):**
- Abra: View → Tool Windows → Device File Explorer
- Navegue: `data/data/com.atelier.control/databases/`
- Baixe `atelier_database` para inspecionar com ferramentas como DB Browser

### Como limpar os dados?

**Opção 1 - Via Android:**
- Settings → Apps → Ateliê Control → Storage → Clear Data

**Opção 2 - Desinstalar o app:**
- Isso apaga o banco automaticamente

---

## 🔧 Como Alterar o Banco de Dados

### Adicionar um novo campo na tabela Cliente

1. Abra [app/src/main/java/com/atelier/control/model/Cliente.kt](app/src/main/java/com/atelier/control/model/Cliente.kt)

2. Adicione o novo campo:
```kotlin
@Entity(tableName = "clientes")
data class Cliente(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nome: String,
    val telefone: String,
    val email: String  // ← Novo campo
)
```

3. **Aumente a versão do banco em** [app/src/main/java/com/atelier/control/database/AppDatabase.kt](app/src/main/java/com/atelier/control/database/AppDatabase.kt):
```kotlin
@Database(
    entities = [Cliente::class, Servico::class],
    version = 2,  // ← Mudar de 1 para 2
    exportSchema = false
)
```

4. **Implemente uma Migration** (se necessário - para apps em produção):
```kotlin
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(database: SupportSQLiteDatabase) {
        database.execSQL("ALTER TABLE clientes ADD COLUMN email TEXT DEFAULT 'N/A'")
    }
}

// Adicione ao databaseBuilder:
Room.databaseBuilder(context, AppDatabase::class.java, "atelier_database")
    .addMigrations(MIGRATION_1_2)
    .build()
```

### Adicionar uma nova tabela

1. Crie uma nova entidade em [model/](app/src/main/java/com/atelier/control/model/)
2. Crie um DAO correspondente em [database/](app/src/main/java/com/atelier/control/database/)
3. Adicione à lista de entidades em AppDatabase
4. Incremente a versão do banco

---

## 📝 Explicação do Código

### 1. Entidades (Models)

Representam as tabelas do banco:

```kotlin
@Entity(tableName = "clientes")
data class Cliente(
    @PrimaryKey(autoGenerate = true)  // Gera ID automaticamente
    val id: Int = 0,
    val nome: String,
    val telefone: String
)
```

### 2. DAOs (Data Access Objects)

Definem as operações no banco:

```kotlin
@Dao
interface ClienteDao {
    @Insert
    suspend fun inserir(cliente: Cliente): Long
    
    @Query("SELECT * FROM clientes")
    fun obterTodos(): Flow<List<Cliente>>
}
```

### 3. Repository

Centraliza a lógica de acesso aos dados:

```kotlin
class AtelieRepository(
    private val clienteDao: ClienteDao,
    private val servicoDao: ServicoDao
) {
    suspend fun inserirCliente(cliente: Cliente) {
        clienteDao.inserir(cliente)
    }
}
```

### 4. ViewModel

Gerencia o estado da UI:

```kotlin
class ClienteViewModel(application: Application) : AndroidViewModel(application) {
    val todosClientes: LiveData<List<Cliente>>
    
    fun inserirCliente(nome: String, telefone: String) {
        viewModelScope.launch {
            repository.inserirCliente(Cliente(nome = nome, telefone = telefone))
        }
    }
}
```

### 5. Activity

A interface com o usuário:

```kotlin
class CadastroClienteActivity : AppCompatActivity() {
    private lateinit var viewModel: ClienteViewModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel = ViewModelProvider(this).get(ClienteViewModel::class.java)
        
        binding.btnSalvar.setOnClickListener {
            viewModel.inserirCliente(nome, telefone)
        }
    }
}
```

---

## 🔄 Fluxo de Dados

```
Activity (UI)
    ↓
ViewModel (Lógica)
    ↓
Repository (Centraliza dados)
    ↓
DAO (Acesso ao banco)
    ↓
Room Database (SQLite)
```

---

## 🎨 Personalização

### Mudar a cor principal

Abra [app/src/main/res/values/colors.xml](app/src/main/res/values/colors.xml):

```xml
<color name="purple_500">#FF6200EE</color>  <!-- Mude essa cor -->
```

### Mudar o nome do app

Abra [app/src/main/res/values/strings.xml](app/src/main/res/values/strings.xml):

```xml
<string name="app_name">Ateliê Control</string>  <!-- Mude para seu nome -->
```

### Adicionar um ícone personalizado

1. Crie um ícone em PNG
2. Coloque em `app/src/main/res/drawable/ic_launcher_foreground.png`
3. Configure em `app/src/main/res/values/ic_launcher_background.xml`

---

## 🐛 Troubleshooting

### Erro: "Package 'com.android.tools.build:gradle' not found"
- Vá para: File → Settings → System Settings → Android SDK
- Baixe a versão SDK necessária

### Erro: "Unresolved reference: 'R'"
- Clique em: Build → Clean Project → Rebuild Project

### Erro ao rodar o app
- Verifique se tem um emulador rodando ou dispositivo conectado
- Tente: Run → Run 'app' (selecione dispositivo)

### Dados não aparecem na lista
- Verifique se está inserindo clientes antes de serviços
- Verifique o Logcat para erros: View → Tool Windows → Logcat

---

## 📱 Telas do Aplicativo

### 1. Tela Inicial
- 3 botões principais
- Acesso rápido às funcionalidades

### 2. Cadastro de Cliente
- Campo Nome
- Campo Telefone
- Validação de campos obrigatórios

### 3. Registro de Serviço
- Seleção de Cliente
- Tipo de Serviço
- DatePicker para Data de Entrega
- Valor (formatação brasileira)

### 4. Listagem de Serviços
- Cards com informações do serviço
- Botão para deletar
- Lista ordenada por data de entrega

---

## 📦 Dependências Utilizadas

```kotlin
// AndroidX
androidx.core:core-ktx:1.10.1
androidx.appcompat:appcompat:1.6.1
androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1

// Material Design
com.google.android.material:material:1.9.0

// Room Database
androidx.room:room-runtime:2.5.2
androidx.room:room-ktx:2.5.2

// Coroutines
org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.1
```

---

## 💡 Dicas de Desenvolvimento

### Debug no Android Studio
1. Defina breakpoints clicando na margem esquerda
2. Rode em Debug (botão com bug)
3. Use Step Over (F10) para debug linha por linha

### Inspecionar Logs
- View → Tool Windows → Logcat
- Procure por "atelier" ou "error" para filtrar

### Usar o Emulador
- Tools → AVD Manager
- Crie um emulador (Android 10 ou superior recomendado)
- Inicie antes de rodar o app

---

## 📄 Licença

Este projeto é fornecido como exemplo educacional.

---

## 🤝 Suporte

Se tiver dúvidas sobre:

- **Room Database**: https://developer.android.com/training/data-storage/room
- **MVVM Architecture**: https://developer.android.com/jetpack/guide
- **Material Design 3**: https://m3.material.io/
- **Android Development**: https://developer.android.com/

---

## ✅ Checklist de Funcionalidades

- [x] CRUD de Clientes (Create, Read, Update, Delete)
- [x] CRUD de Serviços (Create, Read, Update, Delete)
- [x] Relacionamento Cliente → Serviço
- [x] Validação de campos obrigatórios
- [x] Formatação de moeda (R$)
- [x] DatePicker para datas
- [x] RecyclerView com cards
- [x] Material Design 3
- [x] Arquitetura MVVM
- [x] Room Database
- [x] LiveData e Flow
- [x] Coroutines
- [x] Documentação completa

---

Desenvolvido com ❤️ para microempreendedoras
