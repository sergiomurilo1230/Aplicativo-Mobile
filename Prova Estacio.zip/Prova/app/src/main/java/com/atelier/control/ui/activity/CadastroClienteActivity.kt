package com.atelier.control.ui.activity

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.atelier.control.databinding.ActivityCadastroClienteBinding
import com.atelier.control.viewmodel.ClienteViewModel

/**
 * CadastroClienteActivity - Tela para cadastrar novo cliente
 *
 * Campos:
 * - Nome do cliente
 * - Telefone para contato
 *
 * Validações:
 * - Campos obrigatórios não podem ser vazios
 * - Telefone deve ter tamanho mínimo
 */
class CadastroClienteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroClienteBinding
    private lateinit var viewModel: ClienteViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroClienteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializa o ViewModel
        viewModel = ViewModelProvider(this).get(ClienteViewModel::class.java)

        setupToolbar()
        setupListeners()
    }

    /**
     * Configura a toolbar com botão voltar
     */
    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    /**
     * Configura os listeners dos botões
     */
    private fun setupListeners() {
        binding.btnSalvarCliente.setOnClickListener {
            salvarCliente()
        }
    }

    /**
     * Valida e salva o cliente
     */
    private fun salvarCliente() {
        val nome = binding.etNome.text.toString().trim()
        val telefone = binding.etTelefone.text.toString().trim()

        // Validações
        if (!validarCampos(nome, telefone)) {
            return
        }

        // Insere o cliente no banco de dados
        viewModel.inserirCliente(nome, telefone)

        // Exibe mensagem de sucesso
        Toast.makeText(this, "Cliente cadastrado com sucesso!", Toast.LENGTH_SHORT).show()

        // Limpa os campos
        binding.etNome.text.clear()
        binding.etTelefone.text.clear()

        // Volta para tela anterior
        finish()
    }

    /**
     * Valida os campos obrigatórios
     */
    private fun validarCampos(nome: String, telefone: String): Boolean {
        when {
            nome.isEmpty() -> {
                binding.etNome.error = "Nome é obrigatório"
                return false
            }
            telefone.isEmpty() -> {
                binding.etTelefone.error = "Telefone é obrigatório"
                return false
            }
            telefone.length < 10 -> {
                binding.etTelefone.error = "Telefone deve ter no mínimo 10 dígitos"
                return false
            }
        }
        return true
    }
}
