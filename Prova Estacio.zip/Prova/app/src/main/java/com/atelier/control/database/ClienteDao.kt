package com.atelier.control.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.atelier.control.model.Cliente
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object (DAO) para a entidade Cliente
 * Define todas as operações CRUD no banco de dados para clientes
 */
@Dao
interface ClienteDao {

    /**
     * Insere um novo cliente no banco de dados
     */
    @Insert
    suspend fun inserir(cliente: Cliente): Long

    /**
     * Atualiza um cliente existente
     */
    @Update
    suspend fun atualizar(cliente: Cliente)

    /**
     * Deleta um cliente do banco de dados
     */
    @Delete
    suspend fun deletar(cliente: Cliente)

    /**
     * Obtém todos os clientes cadastrados
     * Retorna um Flow que emite atualizações automaticamente
     */
    @Query("SELECT * FROM clientes ORDER BY nome ASC")
    fun obterTodos(): Flow<List<Cliente>>

    /**
     * Obtém um cliente específico pelo ID
     */
    @Query("SELECT * FROM clientes WHERE id = :id")
    suspend fun obterPorId(id: Int): Cliente?

    /**
     * Obtém um cliente pelo nome
     */
    @Query("SELECT * FROM clientes WHERE nome = :nome")
    suspend fun obterPorNome(nome: String): Cliente?
}
