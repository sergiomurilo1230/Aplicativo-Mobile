package com.atelier.control.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.atelier.control.databinding.ItemServicoBinding
import com.atelier.control.model.ServicoComCliente

/**
 * Adapter para exibir a lista de serviços no RecyclerView
 *
 * DiffUtil:
 * - Calcula diferenças entre listas antigas e novas
 * - Anima apenas itens que mudaram
 * - Melhora performance
 */
class ServicoAdapter(
    private val onDeleteClick: (ServicoComCliente) -> Unit
) : ListAdapter<ServicoComCliente, ServicoAdapter.ServicoViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServicoViewHolder {
        val binding = ItemServicoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ServicoViewHolder(binding, onDeleteClick)
    }

    override fun onBindViewHolder(holder: ServicoViewHolder, position: Int) {
        val servico = getItem(position)
        holder.bind(servico)
    }

    /**
     * ViewHolder - Representa cada item da lista
     */
    class ServicoViewHolder(
        private val binding: ItemServicoBinding,
        private val onDeleteClick: (ServicoComCliente) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(servico: ServicoComCliente) {
            binding.apply {
                // Exibe os dados do serviço
                tvNomeCliente.text = servico.clienteNome
                tvDescricao.text = servico.descricao
                tvDataEntrega.text = "Entrega: ${servico.dataEntrega}"
                tvValor.text = servico.valor

                // Botão deletar
                btnDeletear.setOnClickListener {
                    onDeleteClick(servico)
                }
            }
        }
    }

    /**
     * DiffUtil.ItemCallback - Define como comparar itens
     */
    class DiffCallback : DiffUtil.ItemCallback<ServicoComCliente>() {
        override fun areItemsTheSame(
            oldItem: ServicoComCliente,
            newItem: ServicoComCliente
        ): Boolean = oldItem.servicoId == newItem.servicoId

        override fun areContentsTheSame(
            oldItem: ServicoComCliente,
            newItem: ServicoComCliente
        ): Boolean = oldItem == newItem
    }
}
