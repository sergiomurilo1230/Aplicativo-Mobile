package com.atelier.control.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.atelier.control.model.Servico
import com.atelier.control.model.ServicoComCliente
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object (DAO) para a entidade Serviço
 * Define todas as operações CRUD no banco de dados para serviços
 */
@Dao
interface ServicoDao {

    /**
     * Insere um novo serviço no banco de dados
     */
    @Insert
    suspend fun inserir(servico: Servico): Long

    /**
     * Atualiza um serviço existente
     */
    @Update
    suspend fun atualizar(servico: Servico)

    /**
     * Deleta um serviço do banco de dados
     */
    @Delete
    suspend fun deletar(servico: Servico)

    /**
     * Obtém todos os serviços com informações do cliente
     * Retorna um Flow que emite atualizações automaticamente
     */
    @Query("""
        SELECT 
            s.id as servicoId,
            c.nome as clienteNome,
            s.descricao,
            s.dataEntrega,
            s.valor,
            s.clienteId
        FROM servicos s
        INNER JOIN clientes c ON s.clienteId = c.id
        ORDER BY s.dataEntrega ASC
    """)
    fun obterTodosComCliente(): Flow<List<ServicoComCliente>>

    /**
     * Obtém um serviço específico pelo ID
     */
    @Query("SELECT * FROM servicos WHERE id = :id")
    suspend fun obterPorId(id: Int): Servico?

    /**
     * Obtém todos os serviços de um cliente específico
     */
    @Query("SELECT * FROM servicos WHERE clienteId = :clienteId")
    fun obterPorClienteId(clienteId: Int): Flow<List<Servico>>

    /**
     * Conta quantos serviços um cliente tem
     */
    @Query("SELECT COUNT(*) FROM servicos WHERE clienteId = :clienteId")
    suspend fun contarServicosDoCliente(clienteId: Int): Int
}
