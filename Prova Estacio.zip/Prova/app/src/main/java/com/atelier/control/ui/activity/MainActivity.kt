package com.atelier.control.ui.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.atelier.control.databinding.ActivityMainBinding

/**
 * MainActivity - Tela inicial do aplicativo
 *
 * Esta é a tela de apresentação com 3 opções principais:
 * 1. Cadastrar Cliente
 * 2. Registrar Serviço
 * 3. Ver Serviços
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ViewBinding - facilita acesso aos elementos do layout
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupButtons()
    }

    /**
     * Configura a toolbar da Activity
     */
    private fun setupToolbar() {
        binding.toolbar.title = "Ateliê Control"
    }

    /**
     * Configura os listeners dos botões
     */
    private fun setupButtons() {
        // Botão: Cadastrar Cliente
        binding.btnCadastrarCliente.setOnClickListener {
            val intent = Intent(this, CadastroClienteActivity::class.java)
            startActivity(intent)
        }

        // Botão: Registrar Serviço
        binding.btnRegistrarServico.setOnClickListener {
            val intent = Intent(this, RegistroServicoActivity::class.java)
            startActivity(intent)
        }

        // Botão: Ver Serviços
        binding.btnVerServicos.setOnClickListener {
            val intent = Intent(this, ListaServicosActivity::class.java)
            startActivity(intent)
        }
    }
}
