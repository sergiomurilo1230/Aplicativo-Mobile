package com.atelier.control.ui.activity

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.atelier.control.databinding.ActivityListaServicosBinding
import com.atelier.control.ui.adapter.ServicoAdapter
import com.atelier.control.viewmodel.ServicoViewModel

/**
 * ListaServicosActivity - Tela para listar todos os serviços cadastrados
 *
 * Exibe:
 * - Nome do cliente
 * - Descrição do serviço
 * - Data de entrega
 * - Valor cobrado
 * - Botão para deletar serviço
 */
class ListaServicosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListaServicosBinding
    private lateinit var viewModel: ServicoViewModel
    private lateinit var adapter: ServicoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityListaServicosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(ServicoViewModel::class.java)

        setupToolbar()
        setupRecyclerView()
        observarServicos()
    }

    /**
     * Configura a toolbar com botão voltar
     */
    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    /**
     * Configura o RecyclerView
     */
    private fun setupRecyclerView() {
        adapter = ServicoAdapter { servicoComCliente ->
            // Callback quando o usuário clica em deletar
            viewModel.deletarServico(
                servicoComCliente.servicoId,
                servicoComCliente.descricao,
                servicoComCliente.dataEntrega,
                servicoComCliente.valor,
                servicoComCliente.clienteId
            )
            Toast.makeText(this, "Serviço deletado", Toast.LENGTH_SHORT).show()
        }

        binding.recyclerViewServicos.apply {
            layoutManager = LinearLayoutManager(this@ListaServicosActivity)
            adapter = this@ListaServicosActivity.adapter
        }
    }

    /**
     * Observa a lista de serviços do ViewModel
     */
    private fun observarServicos() {
        viewModel.todosServicos.observe(this) { servicos ->
            adapter.submitList(servicos)

            // Exibe mensagem se não houver serviços
            if (servicos.isEmpty()) {
                binding.tvMensagemVazia.text = "Nenhum serviço cadastrado"
                binding.tvMensagemVazia.visibility = android.view.View.VISIBLE
                binding.recyclerViewServicos.visibility = android.view.View.GONE
            } else {
                binding.tvMensagemVazia.visibility = android.view.View.GONE
                binding.recyclerViewServicos.visibility = android.view.View.VISIBLE
            }
        }
    }
}
