package com.atelier.control.model

/**
 * Data class para exibir Serviço com informações do Cliente
 * Usada para exibir na listagem com dados combinados
 */
data class ServicoComCliente(
    val servicoId: Int,
    val clienteNome: String,
    val descricao: String,
    val dataEntrega: String,
    val valor: String,
    val clienteId: Int
)
