# 🔧 Guia de Configuração - Ateliê Control

Este arquivo contém instruções detalhadas para configurar e compilar o projeto.

## 📋 Pré-requisitos

- **Android Studio** 4.2 ou superior
- **Java JDK** 8 ou superior
- **Android SDK** API 26 ou superior
- **Gradle** (incluído no Android Studio)

## 🚀 Primeiros Passos

### 1. Clonar ou Baixar o Projeto

```bash
# Via Git
git clone https://github.com/seu-usuario/atelier-control.git
cd atelier-control

# Ou baixe o ZIP e extraia
```

### 2. Abrir no Android Studio

1. Abra Android Studio
2. Clique em **File → Open**
3. Navegue até a pasta do projeto
4. Clique em **Open**

### 3. Aguardar Sincronização

O Android Studio sincronizará automaticamente:
- Gradle
- Dependências do `build.gradle.kts`
- SDK Android necessário

Se não sincronizar automaticamente:
- **File → Sync Now** (ou Ctrl + Alt + S)

## 📦 Estrutura de Pastas

```
atelier-control/
├── app/                              # Módulo do app
│   ├── build.gradle.kts              # Configurações e dependências
│   ├── src/
│   │   └── main/
│   │       ├── java/com/atelier/control/
│   │       │   ├── model/            # Entidades
│   │       │   ├── database/         # Room DAOs
│   │       │   ├── repository/       # Repository pattern
│   │       │   ├── viewmodel/        # ViewModels
│   │       │   └── ui/
│   │       │       ├── activity/     # Activities
│   │       │       └── adapter/      # Adapters
│   │       ├── res/
│   │       │   ├── layout/           # XMLs das telas
│   │       │   ├── drawable/         # Ícones
│   │       │   ├── values/           # Cores, strings, temas
│   │       │   └── ...
│   │       └── AndroidManifest.xml   # Configuração app
│   └── ...
├── build.gradle.kts                  # Build script do projeto
└── settings.gradle.kts               # Configurações Gradle
```

## 🛠️ Configurações Importantes

### build.gradle.kts (App)

Este arquivo define:
- Versão da SDK: `compileSdk = 34`
- Versão mínima: `minSdk = 26`
- ID do app: `com.atelier.control`
- Dependências necessárias

**Para adicionar novas dependências:**

```kotlin
dependencies {
    // Adicione aqui
    implementation("com.library:name:version")
}
```

Depois sincronize: **File → Sync Now**

### AndroidManifest.xml

Define:
- Nome do aplicativo
- Activities
- Permissões (se necessário)

### settings.gradle.kts

Configura repositórios e plugins do Gradle.

## 🏃 Executar o App

### Opção 1: Emulador

1. **Abrir AVD Manager**: Tools → Device Manager
2. **Criar Emulador**:
   - Clique em **Create Device**
   - Selecione: Pixel 5 (recomendado)
   - Selecione versão Android: 12 ou superior
   - Nomeie e crie
3. **Inicie o Emulador**:
   - Clique no ícone de play do emulador
4. **Rode o App**:
   - Clique em **Run** (botão green play)
   - Selecione o emulador criado
   - Aguarde compilação e execução

### Opção 2: Dispositivo Físico

1. **Ative o Debug do Dispositivo**:
   - Android 11+: Settings → Developer Options → USB Debugging
   - Android 10-: Settings → About Phone → Build Number (7 cliques)
   
2. **Conecte o Dispositivo**:
   - Via USB ao computador
   - Aceite permissão no dispositivo

3. **Rode o App**:
   - Clique em **Run**
   - Selecione o dispositivo
   - Aguarde compilação

## 🔍 Verificar Configuração

### Verificar versões

```bash
# Abra Terminal no Android Studio (ou CMD)
java -version          # Deve ser 1.8 ou superior
gradle --version       # Gradle bundled do Android Studio
```

### Verificar SDK

- Tools → SDK Manager
- Verifique se tem: Android 12, 13, 14 instalados
- Platform Tools deve estar atualizado

### Verificar Emulador

- Tools → Device Manager
- Deve listar emuladores disponíveis

## 🔗 Adicionar Novas Dependências

### Exemplo: Adicionar Retrofit (para API)

1. Abra: `app/build.gradle.kts`
2. Adicione na seção `dependencies`:

```kotlin
// Retrofit
implementation("com.squareup.retrofit2:retrofit:2.9.0")
implementation("com.squareup.retrofit2:converter-gson:2.9.0")
```

3. Sincronize: **File → Sync Now**
4. Pronto! Pode usar no código

## 📝 Criar Nova Activity

### Passo 1: Criar arquivo Kotlin

Arquivo: `app/src/main/java/com/atelier/control/ui/activity/NovaActivity.kt`

```kotlin
package com.atelier.control.ui.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.atelier.control.databinding.ActivityNovaBinding

class NovaActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNovaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNovaBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}
```

### Passo 2: Criar Layout XML

Arquivo: `app/src/main/res/layout/activity_nova.xml`

```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical">
    
    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Minha Nova Tela" />
        
</LinearLayout>
```

### Passo 3: Registrar em AndroidManifest.xml

```xml
<activity
    android:name=".ui.activity.NovaActivity"
    android:exported="false"
    android:parentActivityName=".ui.activity.MainActivity" />
```

### Passo 4: Navegar para a Activity

```kotlin
val intent = Intent(this, NovaActivity::class.java)
startActivity(intent)
```

## 🗄️ Trabalhar com Room Database

### Criar Nova Entidade

1. Crie arquivo: `model/NovaEntidade.kt`

```kotlin
@Entity(tableName = "nova_tabela")
data class NovaEntidade(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val campo1: String,
    val campo2: Int
)
```

2. Crie DAO: `database/NovaEntidadeDao.kt`

```kotlin
@Dao
interface NovaEntidadeDao {
    @Insert
    suspend fun inserir(entidade: NovaEntidade)
    
    @Query("SELECT * FROM nova_tabela")
    fun obterTodos(): Flow<List<NovaEntidade>>
}
```

3. Adicione ao AppDatabase:

```kotlin
@Database(
    entities = [Cliente::class, Servico::class, NovaEntidade::class],
    version = 2
)
abstract class AppDatabase {
    abstract fun novaEntidadeDao(): NovaEntidadeDao
}
```

4. Atualize a versão do banco!

## 🧪 Compilar sem Executar

```bash
# Terminal do Android Studio
./gradlew build

# Ou via GUI
Build → Build Bundle(s)/APK → Build APK(s)
```

## 📦 Criar APK para Distribuição

1. **Build → Build Bundle(s)/APK → Build APK(s)**
2. Aguarde finalizar
3. APK estará em: `app/build/outputs/apk/debug/`

## 🐛 Troubleshooting de Compilação

### Erro: "Unresolved reference"
- **Solução**: Build → Clean Project → Rebuild Project

### Erro: "Gradle sync failed"
- **Solução**: 
  - Verifique internet
  - File → Invalidate Caches / Restart
  - Tente novamente

### Erro: "SDK version mismatch"
- **Solução**:
  - Tools → SDK Manager
  - Instale a versão compileSdk (34 no projeto)
  - Sincronize

### Erro: "Package com.atelier.control not found"
- **Solução**:
  - Build → Clean Project
  - Rebuild Project

## 📱 Emulador Lento?

### Aumentar RAM do Emulador
1. Tools → Device Manager
2. Clique no emulador → Edit
3. Aumente RAM para 4GB
4. Reinicie emulador

### Usar Hardware Acceleration
1. Tools → Device Manager
2. Clique no emulador → Edit
3. Ative "Use Host GPU"
4. Salve e reinicie

## 🔐 Assinatura da APK

Para lançar no Play Store:

1. **Build → Generate Signed Bundle/APK**
2. Selecione **APK**
3. **Create new** se não tiver keystore
4. Preencha dados:
   - Key store path: Escolha local
   - Password: Crie uma senha forte
   - Alias: Algum nome
   - Alias Password: Mesma senha
5. Selecione **Release** como Build Type
6. Finalize e aguarde gerar APK

⚠️ **Guarde a senha e o arquivo do keystore com segurança!**

## 📚 Recursos Úteis

- **Documentação Android**: https://developer.android.com/
- **Kotlin**: https://kotlinlang.org/docs/
- **Room**: https://developer.android.com/training/data-storage/room
- **Material Design**: https://material.io/

---

Pronto para desenvolver! 🚀
