package com.atelier.control.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.atelier.control.model.Cliente
import com.atelier.control.model.Servico

/**
 * Classe que configura o banco de dados Room
 * Define todas as entidades (tabelas) e fornece acesso aos DAOs
 *
 * Como funciona Room:
 * 1. Room cria as tabelas automaticamente baseado nas entidades
 * 2. Os DAOs definem as operações SQL (Select, Insert, Update, Delete)
 * 3. O banco de dados é um Singleton - existe apenas uma instância
 * 4. As operações são executadas em Thread separada (Coroutines)
 */
@Database(
    entities = [Cliente::class, Servico::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    // Fornece acesso ao DAO de Clientes
    abstract fun clienteDao(): ClienteDao

    // Fornece acesso ao DAO de Serviços
    abstract fun servicoDao(): ServicoDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Padrão Singleton para garantir apenas uma instância do banco de dados
         * @param context Contexto da aplicação
         * @return Instância única do AppDatabase
         */
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "atelier_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
