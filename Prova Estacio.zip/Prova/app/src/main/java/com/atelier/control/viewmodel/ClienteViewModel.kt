package com.atelier.control.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.atelier.control.database.AppDatabase
import com.atelier.control.model.Cliente
import com.atelier.control.repository.AtelieRepository
import kotlinx.coroutines.launch

/**
 * ViewModel para gerenciar dados de Clientes
 *
 * AndroidViewModel:
 * - Estende ViewModel
 * - Tem acesso ao Application context
 * - Vive enquanto a Activity está em uso
 * - É destruído quando a Activity é destruída
 *
 * Benefícios:
 * - Dados persistem durante rotação de tela
 * - Não causa memory leak
 * - Centraliza lógica de negócio
 */
class ClienteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AtelieRepository

    // LiveData que a View observa para atualizações
    val todosClientes: LiveData<List<Cliente>>

    init {
        val database = AppDatabase.getDatabase(application)
        val clienteDao = database.clienteDao()
        val servicoDao = database.servicoDao()
        repository = AtelieRepository(clienteDao, servicoDao)

        // Converte Flow em LiveData
        todosClientes = repository.obterTodosClientes().asLiveData()
    }

    /**
     * Insere um novo cliente
     * Executado em thread separada (Coroutine)
     */
    fun inserirCliente(nome: String, telefone: String) {
        viewModelScope.launch {
            val cliente = Cliente(nome = nome, telefone = telefone)
            repository.inserirCliente(cliente)
        }
    }

    /**
     * Deleta um cliente
     */
    fun deletarCliente(cliente: Cliente) {
        viewModelScope.launch {
            repository.deletarCliente(cliente)
        }
    }

    /**
     * Atualiza um cliente
     */
    fun atualizarCliente(cliente: Cliente) {
        viewModelScope.launch {
            repository.atualizarCliente(cliente)
        }
    }
}
