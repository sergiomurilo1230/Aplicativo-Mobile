package com.atelier.control.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

/**
 * Entidade Serviço - Representa um serviço de costura registrado
 * @param id ID único do serviço (gerado automaticamente)
 * @param clienteId ID do cliente (chave estrangeira)
 * @param descricao Descrição do tipo de serviço (ex: "Ajuste de calça", "Reparo de costura")
 * @param dataEntrega Data em que o serviço deve ser entregue
 * @param valor Valor cobrado pelo serviço
 */
@Entity(
    tableName = "servicos",
    foreignKeys = [
        ForeignKey(
            entity = Cliente::class,
            parentColumns = ["id"],
            childColumns = ["clienteId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Servico(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val clienteId: Int,
    val descricao: String,
    val dataEntrega: String,
    val valor: String
)
