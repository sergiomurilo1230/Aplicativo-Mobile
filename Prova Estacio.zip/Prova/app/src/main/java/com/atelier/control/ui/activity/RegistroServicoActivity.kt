package com.atelier.control.ui.activity

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.atelier.control.databinding.ActivityRegistroServicoBinding
import com.atelier.control.viewmodel.ServicoViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * RegistroServicoActivity - Tela para registrar um novo serviço de costura
 *
 * Campos:
 * - Cliente (seleção de spinner com lista de clientes)
 * - Tipo de Serviço (descrição do trabalho)
 * - Data de Entrega (selecionada via DatePicker)
 * - Valor Cobrado (formatado em moeda)
 */
class RegistroServicoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegistroServicoBinding
    private lateinit var viewModel: ServicoViewModel
    private var clienteSelecionado: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRegistroServicoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(ServicoViewModel::class.java)

        setupToolbar()
        setupListeners()
        observarClientes()
    }

    /**
     * Configura a toolbar com botão voltar
     */
    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    /**
     * Observa a lista de clientes do ViewModel
     */
    private fun observarClientes() {
        viewModel.todosClientes.observe(this) { clientes ->
            if (clientes.isEmpty()) {
                Toast.makeText(
                    this,
                    "Cadastre um cliente antes de registrar um serviço",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            } else {
                // Cria lista de nomes dos clientes
                val nomes = clientes.map { it.nome }

                // Configura o adapter do spinner
                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    nomes
                )
                binding.spinnerCliente.adapter = adapter

                // Armazena a lista de clientes para obter o ID depois
                binding.spinnerCliente.onItemSelectedListener =
                    object : android.widget.AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(
                            parent: android.widget.AdapterView<*>?,
                            view: android.view.View?,
                            position: Int,
                            id: Long
                        ) {
                            clienteSelecionado = clientes[position].id
                        }

                        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {
                            clienteSelecionado = -1
                        }
                    }
            }
        }
    }

    /**
     * Configura os listeners dos elementos
     */
    private fun setupListeners() {
        // Clique na data de entrega - abre DatePicker
        binding.etDataEntrega.setOnClickListener {
            abrirDatePicker()
        }

        // Botão salvar
        binding.btnSalvarServico.setOnClickListener {
            salvarServico()
        }
    }

    /**
     * Abre o DatePicker para seleção de data
     */
    private fun abrirDatePicker() {
        val calendar = Calendar.getInstance()
        val ano = calendar.get(Calendar.YEAR)
        val mes = calendar.get(Calendar.MONTH)
        val dia = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, monthOfYear, dayOfMonth ->
                // Formata a data selecionada
                val dataSelecionada = String.format(
                    "%02d/%02d/%04d",
                    dayOfMonth,
                    monthOfYear + 1,
                    year
                )
                binding.etDataEntrega.setText(dataSelecionada)
            },
            ano,
            mes,
            dia
        )

        datePickerDialog.show()
    }

    /**
     * Valida e salva o serviço
     */
    private fun salvarServico() {
        val descricao = binding.etTipoServico.text.toString().trim()
        val dataEntrega = binding.etDataEntrega.text.toString().trim()
        val valor = binding.etValor.text.toString().trim()

        // Validações
        if (!validarCampos(descricao, dataEntrega, valor)) {
            return
        }

        if (clienteSelecionado == -1) {
            Toast.makeText(this, "Selecione um cliente", Toast.LENGTH_SHORT).show()
            return
        }

        // Formata o valor para o padrão brasileiro
        val valorFormatado = formatarValor(valor)

        // Insere o serviço no banco de dados
        viewModel.inserirServico(clienteSelecionado, descricao, dataEntrega, valorFormatado)

        Toast.makeText(this, "Serviço registrado com sucesso!", Toast.LENGTH_SHORT).show()

        // Limpa os campos
        binding.etTipoServico.text.clear()
        binding.etDataEntrega.text.clear()
        binding.etValor.text.clear()

        // Volta para tela anterior
        finish()
    }

    /**
     * Valida os campos obrigatórios
     */
    private fun validarCampos(descricao: String, dataEntrega: String, valor: String): Boolean {
        when {
            descricao.isEmpty() -> {
                binding.etTipoServico.error = "Tipo de serviço é obrigatório"
                return false
            }
            dataEntrega.isEmpty() -> {
                binding.etDataEntrega.error = "Data de entrega é obrigatória"
                return false
            }
            valor.isEmpty() -> {
                binding.etValor.error = "Valor é obrigatório"
                return false
            }
            valor.toDoubleOrNull() == null -> {
                binding.etValor.error = "Valor deve ser um número válido"
                return false
            }
            valor.toDouble() <= 0 -> {
                binding.etValor.error = "Valor deve ser maior que zero"
                return false
            }
        }
        return true
    }

    /**
     * Formata o valor em moeda brasileira
     * Ex: "150.50" -> "R$ 150,50"
     */
    private fun formatarValor(valor: String): String {
        val numero = valor.replace(",", ".").toDoubleOrNull() ?: 0.0
        return String.format("R$ %.2f", numero)
    }
}
